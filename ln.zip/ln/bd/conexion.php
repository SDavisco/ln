<?php
 $conn = new mysqli('localhost','davisco_sistemas','admin123','lnv_prueba');
  if($conn->connect_error){
 	echo $error -> $connect_error;
 }
?>
